<!-- javascript libraries -->
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="./assets/js/jquery.js"></script>
        <script type="text/javascript" src="./assets/js/jquery.js"></script>
        <script type="text/javascript" src="./assets/js/vendors.min.js"></script>
        <script type="text/javascript" src="./assets/js/main.js"></script>