<head>
        <title>Al Thabitah</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="author" content="ThemeZaa">
        <meta name="viewport" content="width=device-width,initial-scale=1.0" />
        <!-- favicon icon -->
        <link rel="shortcut icon" href="./assets/images/logo-02.png">
        <!-- google fonts preconnect -->
        <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <!-- style sheets and font icons  -->
        <link rel="stylesheet" href="./assets/css/vendors.min.css"/>
        <link rel="stylesheet" href="./assets/css/icon.min.css"/>
        <link rel="stylesheet" href="./assets/css/style.min.css"/>
        <link rel="stylesheet" href="./assets/css/responsive.min.css"/>
        <link rel="stylesheet" href="./assets/css/styles.css"/>
    </head>