<div class="bg-very-light-gray border-radius-6px p-45px lg-p-25px mb-25px">
                            <span class="fs-22 text-dark-gray fw-600 mb-20px d-inline-block">Our Services</span>
                            <ul class="p-0 m-0 list-style-02 fw-500">
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="house-cleaning.php">House Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="office-cleaning.php">Office Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="kitchen-cleaning.php">Kitchen Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="water-tank-cleaning.php">Water Tank Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="window-cleaning.php">Window Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="plumbing-service.php">Plumbing Service</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="pest-control-service.php">Pest Control Service</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="sofa-cleaning.php">Sofa Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="carpet-cleaning.php">Carpet Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="mattress-cleaning.php">Mattress Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                                <li class="pb-5px mb-10px border-bottom border-color-transparent-dark"><a href="curtain-cleaning.php">Curtain Cleaning</a><i class="feather icon-feather-arrow-right ms-auto icon-small"></i></li>
                            </ul>
                        </div>